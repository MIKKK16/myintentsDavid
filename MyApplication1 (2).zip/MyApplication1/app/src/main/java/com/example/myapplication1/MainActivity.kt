package com.example.myapplication1

import android.content.Intent
import android.net.Uri
import android.net.Uri.*
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val btnMoveActity = findViewById<Button>(R.id.btn_main_activity)
        btnMoveActity.setOnClickListener {
            onClick()
        }
        val btnDialNumber = findViewById<Button>(R.id.btn_dial_number)
        btnDialNumber.setOnClickListener {
            onDial()

        }
        val btnDialNumber2 = findViewById<Button>(R.id.btn_dial_number2)
        btnDialNumber2.setOnClickListener {
            onDial2()

        }
    }

    private fun onClick() {
        val intent = Intent(applicationContext, MainActivity::class.java)
        startActivity(intent)

    }


    private fun onDial() {
        val dialNumber = "082272209991"
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + dialNumber))
        startActivity(intent)
    }

    private fun onDial2() {
        val dialNumber2 = "082272209992"
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + dialNumber2))
        startActivity(intent)
    }

}


